// ============================================================================
// Eagle Insight - Real-Time Insights Engine
// Improvement #2: Real-Time Insights Support with WebSockets & Supabase
// ============================================================================

import { createClient, RealtimeChannel, SupabaseClient } from '@supabase/supabase-js';

// Types for insights
export interface FlightData {
  id: string;
  aircraft_id: string;
  flight_number: string;
  departure_time: Date;
  arrival_time: Date;
  route: string;
  status: string;
  flight_hours: number;
  cycles: number;
  fuel_consumption: number;
  notes?: string;
  created_at: Date;
  updated_at: Date;
}

export interface MaintenanceInsight {
  id: string;
  aircraft_id: string;
  insight_type: InsightType;
  severity: InsightSeverity;
  title: string;
  description: string;
  recommendation: string;
  confidence_score: number;
  related_data: Record<string, unknown>;
  is_acknowledged: boolean;
  acknowledged_by?: string;
  acknowledged_at?: Date;
  created_at: Date;
}

export type InsightType = 
  | 'predictive_maintenance'
  | 'anomaly_detection'
  | 'performance_degradation'
  | 'compliance_alert'
  | 'parts_replacement'
  | 'operational_efficiency';

export type InsightSeverity = 'critical' | 'high' | 'medium' | 'low' | 'info';

export interface InsightGenerationConfig {
  enablePredictiveMaintenance: boolean;
  enableAnomalyDetection: boolean;
  enableComplianceAlerts: boolean;
  confidenceThreshold: number;
  alertOnCritical: boolean;
  notifyRoles: string[];
}

type InsightEventHandler = (insight: MaintenanceInsight) => void;
type DataUpdateHandler<T> = (payload: { new: T; old?: T }) => void;

interface InsightEngineSubscribers {
  onNewInsight: InsightEventHandler[];
  onInsightUpdated: InsightEventHandler[];
  onCriticalAlert: InsightEventHandler[];
}

/**
 * RealTimeInsightsEngine - Manages real-time insight generation and subscriptions
 * 
 * Features:
 * - Real-time data monitoring via Supabase
 * - Automatic insight generation on data changes
 * - WebSocket-based notifications
 * - Configurable insight generation rules
 */
export class RealTimeInsightsEngine {
  private supabase: SupabaseClient | null = null;
  private channels: Map<string, RealtimeChannel> = new Map();
  private subscribers: InsightEngineSubscribers = {
    onNewInsight: [],
    onInsightUpdated: [],
    onCriticalAlert: [],
  };
  private config: InsightGenerationConfig;
  private isInitialized: boolean = false;

  constructor(config?: Partial<InsightGenerationConfig>) {
    this.config = {
      enablePredictiveMaintenance: true,
      enableAnomalyDetection: true,
      enableComplianceAlerts: true,
      confidenceThreshold: 0.7,
      alertOnCritical: true,
      notifyRoles: ['maintenance_team_leader', 'admin'],
      ...config,
    };
  }

  /**
   * Initialize the insights engine with Supabase credentials
   */
  public async initialize(supabaseUrl: string, supabaseKey: string): Promise<void> {
    if (this.isInitialized) {
      console.warn('RealTimeInsightsEngine is already initialized');
      return;
    }

    this.supabase = createClient(supabaseUrl, supabaseKey, {
      realtime: {
        params: {
          eventsPerSecond: 10,
        },
      },
    });

    this.isInitialized = true;
    await this.setupDefaultSubscriptions();
  }

  /**
   * Subscribe to real-time updates for a specific table
   */
  public subscribeToTable<T>(
    tableName: string,
    event: 'INSERT' | 'UPDATE' | 'DELETE' | '*',
    handler: DataUpdateHandler<T>
  ): void {
    if (!this.supabase) {
      throw new Error('RealTimeInsightsEngine not initialized. Call initialize() first.');
    }

    const channelKey = `${tableName}_${event}`;
    
    // Remove existing subscription if any
    this.unsubscribeFromTable(channelKey);

    const channel = this.supabase
      .channel(channelKey)
      .on(
        'postgres_changes',
        {
          event: event === '*' ? undefined : event,
          schema: 'public',
          table: tableName,
        },
        (payload) => {
          handler(payload as unknown as { new: T; old?: T });
        }
      )
      .subscribe();

    this.channels.set(channelKey, channel);
  }

  /**
   * Unsubscribe from a table's real-time updates
   */
  public unsubscribeFromTable(channelKey: string): void {
    const channel = this.channels.get(channelKey);
    if (channel && this.supabase) {
      this.supabase.removeChannel(channel);
      this.channels.delete(channelKey);
    }
  }

  /**
   * Subscribe to insight events
   */
  public onNewInsight(handler: InsightEventHandler): () => void {
    this.subscribers.onNewInsight.push(handler);
    return () => {
      this.subscribers.onNewInsight = this.subscribers.onNewInsight.filter(
        (h) => h !== handler
      );
    };
  }

  /**
   * Subscribe to insight update events
   */
  public onInsightUpdated(handler: InsightEventHandler): () => void {
    this.subscribers.onInsightUpdated.push(handler);
    return () => {
      this.subscribers.onInsightUpdated = this.subscribers.onInsightUpdated.filter(
        (h) => h !== handler
      );
    };
  }

  /**
   * Subscribe to critical alert events
   */
  public onCriticalAlert(handler: InsightEventHandler): () => void {
    this.subscribers.onCriticalAlert.push(handler);
    return () => {
      this.subscribers.onCriticalAlert = this.subscribers.onCriticalAlert.filter(
        (h) => h !== handler
      );
    };
  }

  /**
   * Generate maintenance insights from flight data
   */
  public async generateMaintenanceInsights(
    flightData: FlightData
  ): Promise<MaintenanceInsight[]> {
    const insights: MaintenanceInsight[] = [];

    if (this.config.enablePredictiveMaintenance) {
      const maintenanceInsight = await this.analyzePredictiveMaintenance(flightData);
      if (maintenanceInsight) {
        insights.push(maintenanceInsight);
      }
    }

    if (this.config.enableAnomalyDetection) {
      const anomalyInsights = await this.detectAnomalies(flightData);
      insights.push(...anomalyInsights);
    }

    if (this.config.enableComplianceAlerts) {
      const complianceInsights = await this.checkCompliance(flightData);
      insights.push(...complianceInsights);
    }

    // Filter by confidence threshold
    const filteredInsights = insights.filter(
      (insight) => insight.confidence_score >= this.config.confidenceThreshold
    );

    // Notify subscribers
    for (const insight of filteredInsights) {
      this.notifyNewInsight(insight);
    }

    return filteredInsights;
  }

  /**
   * Update insight configuration
   */
  public updateConfig(updates: Partial<InsightGenerationConfig>): void {
    this.config = { ...this.config, ...updates };
  }

  /**
   * Get current configuration
   */
  public getConfig(): InsightGenerationConfig {
    return { ...this.config };
  }

  /**
   * Cleanup and disconnect all subscriptions
   */
  public async destroy(): Promise<void> {
    for (const channelKey of this.channels.keys()) {
      this.unsubscribeFromTable(channelKey);
    }
    
    if (this.supabase) {
      await this.supabase.removeAllChannels();
    }
    
    this.isInitialized = false;
    this.subscribers = {
      onNewInsight: [],
      onInsightUpdated: [],
      onCriticalAlert: [],
    };
  }

  // Private methods

  private async setupDefaultSubscriptions(): Promise<void> {
    // Subscribe to flight data changes
    this.subscribeToTable<FlightData>(
      'flight_data',
      'INSERT',
      async (payload) => {
        await this.generateMaintenanceInsights(payload.new);
      }
    );

    this.subscribeToTable<FlightData>(
      'flight_data',
      'UPDATE',
      async (payload) => {
        await this.generateMaintenanceInsights(payload.new);
      }
    );

    // Subscribe to maintenance insights updates
    this.subscribeToTable<MaintenanceInsight>(
      'maintenance_insights',
      'INSERT',
      (payload) => {
        this.notifyNewInsight(payload.new);
      }
    );

    this.subscribeToTable<MaintenanceInsight>(
      'maintenance_insights',
      'UPDATE',
      (payload) => {
        this.notifyInsightUpdated(payload.new);
      }
    );
  }

  private async analyzePredictiveMaintenance(
    flightData: FlightData
  ): Promise<MaintenanceInsight | null> {
    // Analyze flight hours and cycles for predictive maintenance
    const thresholds = {
      flightHours: 500,
      cycles: 300,
    };

    if (
      flightData.flight_hours > thresholds.flightHours ||
      flightData.cycles > thresholds.cycles
    ) {
      const severity: InsightSeverity =
        flightData.flight_hours > thresholds.flightHours * 1.2 ? 'high' : 'medium';

      return this.createInsight({
        aircraft_id: flightData.aircraft_id,
        insight_type: 'predictive_maintenance',
        severity,
        title: 'Scheduled Maintenance Approaching',
        description: `Aircraft ${flightData.aircraft_id} is approaching maintenance threshold. ` +
          `Current flight hours: ${flightData.flight_hours}, Cycles: ${flightData.cycles}`,
        recommendation: 'Schedule routine maintenance inspection within the next 5-10 flight cycles.',
        confidence_score: 0.85,
        related_data: {
          flight_hours: flightData.flight_hours,
          cycles: flightData.cycles,
          thresholds,
        },
      });
    }

    return null;
  }

  private async detectAnomalies(
    flightData: FlightData
  ): Promise<MaintenanceInsight[]> {
    const insights: MaintenanceInsight[] = [];

    // Check for abnormal fuel consumption
    const expectedFuelConsumption = flightData.flight_hours * 800; // kg/hour estimate
    const actualConsumption = flightData.fuel_consumption;
    const consumptionVariance = Math.abs(actualConsumption - expectedFuelConsumption) / expectedFuelConsumption;

    if (consumptionVariance > 0.15) {
      insights.push(
        this.createInsight({
          aircraft_id: flightData.aircraft_id,
          insight_type: 'anomaly_detection',
          severity: consumptionVariance > 0.25 ? 'high' : 'medium',
          title: 'Abnormal Fuel Consumption Detected',
          description: `Flight ${flightData.flight_number} showed ${(consumptionVariance * 100).toFixed(1)}% ` +
            `variance in fuel consumption from expected levels.`,
          recommendation: 'Investigate engine efficiency and check for potential fuel system issues.',
          confidence_score: 0.78,
          related_data: {
            expected_consumption: expectedFuelConsumption,
            actual_consumption: actualConsumption,
            variance_percentage: consumptionVariance * 100,
          },
        })
      );
    }

    return insights;
  }

  private async checkCompliance(
    flightData: FlightData
  ): Promise<MaintenanceInsight[]> {
    const insights: MaintenanceInsight[] = [];

    // Check for compliance-related issues
    const maxFlightHoursWithoutInspection = 600;
    
    if (flightData.flight_hours > maxFlightHoursWithoutInspection) {
      insights.push(
        this.createInsight({
          aircraft_id: flightData.aircraft_id,
          insight_type: 'compliance_alert',
          severity: 'critical',
          title: 'Compliance Inspection Required',
          description: `Aircraft ${flightData.aircraft_id} has exceeded maximum flight hours ` +
            `(${maxFlightHoursWithoutInspection}h) without required compliance inspection.`,
          recommendation: 'Ground aircraft and schedule compliance inspection immediately.',
          confidence_score: 0.95,
          related_data: {
            flight_hours: flightData.flight_hours,
            max_allowed: maxFlightHoursWithoutInspection,
          },
        })
      );
    }

    return insights;
  }

  private createInsight(
    data: Omit<MaintenanceInsight, 'id' | 'is_acknowledged' | 'created_at'>
  ): MaintenanceInsight {
    return {
      id: crypto.randomUUID(),
      ...data,
      is_acknowledged: false,
      created_at: new Date(),
    };
  }

  private notifyNewInsight(insight: MaintenanceInsight): void {
    for (const handler of this.subscribers.onNewInsight) {
      try {
        handler(insight);
      } catch (error) {
        console.error('Error in onNewInsight handler:', error);
      }
    }

    if (this.config.alertOnCritical && insight.severity === 'critical') {
      this.notifyCriticalAlert(insight);
    }
  }

  private notifyInsightUpdated(insight: MaintenanceInsight): void {
    for (const handler of this.subscribers.onInsightUpdated) {
      try {
        handler(insight);
      } catch (error) {
        console.error('Error in onInsightUpdated handler:', error);
      }
    }
  }

  private notifyCriticalAlert(insight: MaintenanceInsight): void {
    for (const handler of this.subscribers.onCriticalAlert) {
      try {
        handler(insight);
      } catch (error) {
        console.error('Error in onCriticalAlert handler:', error);
      }
    }
  }
}

// Export singleton instance
export const insightsEngine = new RealTimeInsightsEngine();

// React hook for using the insights engine
export function useInsightsEngine() {
  return insightsEngine;
}
