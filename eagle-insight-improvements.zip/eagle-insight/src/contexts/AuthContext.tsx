// ============================================================================
// Eagle Insight - Authentication Context
// Provides role-based access control throughout the application
// ============================================================================

import React, { createContext, useContext, useState, useCallback, useMemo, ReactNode } from 'react';
import { 
  User, 
  UserRole, 
  AuthState, 
  ROLE_PERMISSIONS, 
  PERMISSIONS 
} from '../types/auth.types';

interface AuthContextValue extends AuthState {
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  hasPermission: (permission: string) => boolean;
  hasAnyPermission: (permissions: string[]) => boolean;
  hasAllPermissions: (permissions: string[]) => boolean;
  hasRole: (role: UserRole) => boolean;
  hasAnyRole: (roles: UserRole[]) => boolean;
  canAccessFeature: (feature: FeatureKey) => boolean;
}

// Feature-to-permission mappings for high-level feature access checks
export type FeatureKey = 
  | 'reports'
  | 'reports_create'
  | 'reports_edit'
  | 'reports_delete'
  | 'findings'
  | 'findings_create'
  | 'findings_sort'
  | 'findings_assign'
  | 'findings_close'
  | 'maintenance'
  | 'maintenance_create'
  | 'maintenance_approve'
  | 'maintenance_schedule'
  | 'insights'
  | 'insights_configure'
  | 'file_upload'
  | 'file_delete'
  | 'admin'
  | 'user_management'
  | 'settings'
  | 'audit_logs'
  | 'data_sources'
  | 'data_sources_manage';

const FEATURE_PERMISSIONS: Record<FeatureKey, string[]> = {
  reports: [PERMISSIONS.VIEW_REPORTS],
  reports_create: [PERMISSIONS.CREATE_REPORTS],
  reports_edit: [PERMISSIONS.EDIT_REPORTS],
  reports_delete: [PERMISSIONS.DELETE_REPORTS],
  findings: [PERMISSIONS.VIEW_FINDINGS],
  findings_create: [PERMISSIONS.CREATE_FINDINGS],
  findings_sort: [PERMISSIONS.SORT_FINDINGS],
  findings_assign: [PERMISSIONS.ASSIGN_FINDINGS],
  findings_close: [PERMISSIONS.CLOSE_FINDINGS],
  maintenance: [PERMISSIONS.VIEW_MAINTENANCE],
  maintenance_create: [PERMISSIONS.CREATE_MAINTENANCE_TASK],
  maintenance_approve: [PERMISSIONS.APPROVE_MAINTENANCE],
  maintenance_schedule: [PERMISSIONS.SCHEDULE_MAINTENANCE],
  insights: [PERMISSIONS.VIEW_INSIGHTS],
  insights_configure: [PERMISSIONS.CONFIGURE_INSIGHTS],
  file_upload: [PERMISSIONS.UPLOAD_FILES],
  file_delete: [PERMISSIONS.DELETE_FILES],
  admin: [PERMISSIONS.MANAGE_USERS, PERMISSIONS.MANAGE_SETTINGS],
  user_management: [PERMISSIONS.MANAGE_USERS],
  settings: [PERMISSIONS.MANAGE_SETTINGS],
  audit_logs: [PERMISSIONS.VIEW_AUDIT_LOGS],
  data_sources: [PERMISSIONS.VIEW_DATA_SOURCES],
  data_sources_manage: [PERMISSIONS.MANAGE_DATA_SOURCES],
};

const AuthContext = createContext<AuthContextValue | null>(null);

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [state, setState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true,
    error: null,
  });

  // Get permissions for the current user's role
  const userPermissions = useMemo(() => {
    if (!state.user) return [];
    return ROLE_PERMISSIONS[state.user.role] || [];
  }, [state.user]);

  // Check if user has a specific permission
  const hasPermission = useCallback(
    (permission: string): boolean => {
      return userPermissions.includes(permission);
    },
    [userPermissions]
  );

  // Check if user has any of the specified permissions
  const hasAnyPermission = useCallback(
    (permissions: string[]): boolean => {
      return permissions.some((permission) => userPermissions.includes(permission));
    },
    [userPermissions]
  );

  // Check if user has all specified permissions
  const hasAllPermissions = useCallback(
    (permissions: string[]): boolean => {
      return permissions.every((permission) => userPermissions.includes(permission));
    },
    [userPermissions]
  );

  // Check if user has a specific role
  const hasRole = useCallback(
    (role: UserRole): boolean => {
      return state.user?.role === role;
    },
    [state.user]
  );

  // Check if user has any of the specified roles
  const hasAnyRole = useCallback(
    (roles: UserRole[]): boolean => {
      return state.user ? roles.includes(state.user.role) : false;
    },
    [state.user]
  );

  // Check if user can access a high-level feature
  const canAccessFeature = useCallback(
    (feature: FeatureKey): boolean => {
      const requiredPermissions = FEATURE_PERMISSIONS[feature];
      return hasAnyPermission(requiredPermissions);
    },
    [hasAnyPermission]
  );

  // Login function
  const login = useCallback(async (email: string, password: string) => {
    setState((prev) => ({ ...prev, isLoading: true, error: null }));

    try {
      // This would be replaced with actual API call
      const response = await mockLoginAPI(email, password);
      
      setState({
        user: response.user,
        isAuthenticated: true,
        isLoading: false,
        error: null,
      });
    } catch (error) {
      setState((prev) => ({
        ...prev,
        isLoading: false,
        error: error instanceof Error ? error.message : 'Login failed',
      }));
      throw error;
    }
  }, []);

  // Logout function
  const logout = useCallback(async () => {
    setState((prev) => ({ ...prev, isLoading: true }));

    try {
      // This would be replaced with actual API call
      await mockLogoutAPI();
      
      setState({
        user: null,
        isAuthenticated: false,
        isLoading: false,
        error: null,
      });
    } catch (error) {
      setState((prev) => ({
        ...prev,
        isLoading: false,
        error: error instanceof Error ? error.message : 'Logout failed',
      }));
    }
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      ...state,
      login,
      logout,
      hasPermission,
      hasAnyPermission,
      hasAllPermissions,
      hasRole,
      hasAnyRole,
      canAccessFeature,
    }),
    [state, login, logout, hasPermission, hasAnyPermission, hasAllPermissions, hasRole, hasAnyRole, canAccessFeature]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// Custom hook to use auth context
export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

// Hook for checking a single permission
export function usePermission(permission: string): boolean {
  const { hasPermission } = useAuth();
  return hasPermission(permission);
}

// Hook for checking feature access
export function useFeatureAccess(feature: FeatureKey): boolean {
  const { canAccessFeature } = useAuth();
  return canAccessFeature(feature);
}

// Mock API functions (replace with actual API calls)
async function mockLoginAPI(email: string, _password: string): Promise<{ user: User }> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500));

  // Mock user based on email domain for demo purposes
  const roleMap: Record<string, UserRole> = {
    'admin@eagle.com': 'admin',
    'leader@eagle.com': 'maintenance_team_leader',
    'tech@eagle.com': 'maintenance_technician',
    'inspector@eagle.com': 'quality_inspector',
    'ops@eagle.com': 'flight_operations',
    'viewer@eagle.com': 'viewer',
  };

  const role = roleMap[email] || 'viewer';

  return {
    user: {
      id: crypto.randomUUID(),
      email,
      name: email.split('@')[0],
      role,
      isActive: true,
      createdAt: new Date(),
      lastLogin: new Date(),
    },
  };
}

async function mockLogoutAPI(): Promise<void> {
  await new Promise((resolve) => setTimeout(resolve, 200));
}

export { AuthContext };
