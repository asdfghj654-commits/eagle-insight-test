# Eagle Insight - Aviation Maintenance System

## Implemented Improvements

This codebase implements all 6 requested improvements for the Eagle Insight aviation maintenance system.

---

## 1. Multi-Database Connection Management

**File:** `src/services/data-source-manager.ts`

### Features:
- Support for multiple simultaneous SQL database connections
- Flexible configuration for PostgreSQL, MySQL, MSSQL, SQLite, Oracle
- Connection pooling with configurable pool sizes
- Health monitoring with automatic failure detection
- Event-driven architecture with handlers for connect/disconnect/error events

### Usage Example:
```typescript
import { DataSourceManager } from './services/data-source-manager';

const manager = new DataSourceManager();

// Add multiple databases
manager.addDataSource('production', {
  id: 'production',
  name: 'Production DB',
  type: 'postgresql',
  host: 'prod.example.com',
  port: 5432,
  database: 'eagle_insight',
  username: 'admin',
  password: 'secret',
});

manager.addDataSource('analytics', {
  id: 'analytics',
  name: 'Analytics DB',
  type: 'mysql',
  host: 'analytics.example.com',
  port: 3306,
  database: 'analytics',
  username: 'reader',
  password: 'secret',
});

// Connect to all
await manager.connectToAllDatabases();

// Query specific database
const results = await manager.query('production', 'SELECT * FROM findings');

// Health check all
const health = await manager.healthCheckAll();
```

---

## 2. Real-Time Insights Support

**File:** `src/services/insights-engine.ts`

### Features:
- Supabase real-time subscriptions for live data updates
- WebSocket-based monitoring of flight_data and maintenance_insights tables
- Automatic insight generation on INSERT/UPDATE events
- Configurable thresholds and notification rules
- Multiple insight types: predictive_maintenance, anomaly_detection, compliance_alert, etc.

### Usage Example:
```typescript
import { RealTimeInsightsEngine } from './services/insights-engine';

const engine = new RealTimeInsightsEngine({
  supabaseUrl: 'https://your-project.supabase.co',
  supabaseKey: 'your-anon-key',
  thresholds: {
    flightHoursWarning: 1000,
    cyclesWarning: 500,
    fuelConsumptionDeviation: 0.1,
  },
});

// Set up event handlers
engine.onNewInsight((insight) => {
  console.log('New insight generated:', insight);
});

engine.onCriticalAlert((insight) => {
  notifyMaintenanceTeam(insight);
});

// Start monitoring
await engine.startMonitoring();
```

---

## 3. UX/UI Improvements

### File Upload Component
**File:** `src/components/ui/FileUpload.tsx`

Features:
- Drag-and-drop support
- Real-time validation (file type, size, custom validators)
- Visual feedback with progress bars
- Image preview for uploaded images
- Upload status tracking (pending, uploading, success, error)
- Retry failed uploads
- Accessible with keyboard navigation and ARIA labels

### Toast Notifications
**File:** `src/components/ui/Toast.tsx`

Features:
- 4 notification types: success, error, warning, info
- 6 position options
- Auto-dismiss with configurable duration
- Progress bar animation
- ARIA live regions for screen readers
- Dismissible with close button
- Optional action buttons

---

## 4. Accessibility Features

### All components include:
- Proper ARIA labels on interactive elements
- Keyboard navigation support
- Screen reader compatibility
- Focus management with visible focus rings
- Semantic HTML structure
- Color contrast compliance

### Example:
```tsx
<Button
  aria-label="Upload CSV file"
  onClick={handleFileUpload}
  leftIcon={<UploadIcon />}
>
  Upload File
</Button>
```

---

## 5. UI Styling System

**File:** `src/components/ui/Button.tsx`

### Button Variants:
- `primary` - Main action buttons (blue)
- `secondary` - Secondary actions (gray)
- `danger` - Destructive actions (red)
- `warning` - Warning actions (amber)
- `success` - Success actions (green)
- `ghost` - Minimal styling
- `link` - Link-styled buttons
- `outline` / `outlinePrimary` - Outlined buttons

### Button Sizes:
- `xs`, `sm`, `md`, `lg`, `xl` - Standard sizes
- `icon`, `iconSm`, `iconLg` - Icon-only buttons

---

## 6. Role-Based Access Control (RBAC)

### The Most Important Feature!

**Files:**
- `src/types/auth.types.ts` - Permission definitions
- `src/contexts/AuthContext.tsx` - Auth state and permission checks
- `src/components/common/RoleBasedAccess.tsx` - Conditional rendering components

### User Roles:
| Role | Description |
|------|-------------|
| `admin` | Full access to all features |
| `maintenance_team_leader` | Can sort/assign findings, view team reports |
| `maintenance_technician` | Can create/edit findings |
| `quality_inspector` | Can sort/close findings, create reports |
| `flight_operations` | Read-only access to reports and findings |
| `viewer` | Read-only access |

### Key Permissions:
```typescript
PERMISSIONS = {
  // Reports
  VIEW_REPORTS, CREATE_REPORTS, EDIT_REPORTS, DELETE_REPORTS, EXPORT_REPORTS,
  
  // Findings
  VIEW_FINDINGS, CREATE_FINDINGS, EDIT_FINDINGS, DELETE_FINDINGS,
  SORT_FINDINGS, ASSIGN_FINDINGS, CLOSE_FINDINGS,
  
  // Maintenance
  VIEW_MAINTENANCE, CREATE_MAINTENANCE_TASK, APPROVE_MAINTENANCE, SCHEDULE_MAINTENANCE,
  
  // Administration
  MANAGE_USERS, MANAGE_SETTINGS, VIEW_AUDIT_LOGS
}
```

### How Unauthorized Features Are Hidden

Using `PermissionGate`, `RoleGate`, and `FeatureGate` components, unauthorized UI elements are **completely hidden** from the user:

```tsx
// Sort button - only visible with SORT_FINDINGS permission
<PermissionGate permission={PERMISSIONS.SORT_FINDINGS}>
  <Button onClick={handleSort}>Sort Findings</Button>
</PermissionGate>

// Team Leader Reports - only visible to specific roles
<RoleGate role={['admin', 'maintenance_team_leader']}>
  <TeamLeaderReportsSection />
</RoleGate>

// Create button - based on feature access
<FeatureGate feature="reports_create">
  <Button onClick={handleCreate}>Create Report</Button>
</FeatureGate>
```

### Visual Demonstration

See the demo pages for working examples:
- `src/components/features/FindingsPage.tsx` - Shows role-based button visibility
- `src/components/features/ReportsPage.tsx` - Shows role-based report filtering

---

## File Structure

```
eagle-insight/
├── src/
│   ├── components/
│   │   ├── ui/
│   │   │   ├── Button.tsx         # Accessible button with variants
│   │   │   ├── Toast.tsx          # Toast notification system
│   │   │   └── FileUpload.tsx     # Enhanced file upload
│   │   ├── common/
│   │   │   └── RoleBasedAccess.tsx  # Permission gates
│   │   └── features/
│   │       ├── FindingsPage.tsx   # Demo: role-based findings
│   │       └── ReportsPage.tsx    # Demo: role-based reports
│   ├── contexts/
│   │   └── AuthContext.tsx        # Auth state & hooks
│   ├── services/
│   │   ├── data-source-manager.ts # Multi-DB connections
│   │   └── insights-engine.ts     # Real-time insights
│   ├── types/
│   │   └── auth.types.ts          # Permissions & roles
│   └── lib/
│       └── utils.ts               # Utility functions
└── README.md
```

---

## Quick Start

1. Install dependencies:
```bash
npm install
```

2. Set up environment variables:
```env
VITE_SUPABASE_URL=your-supabase-url
VITE_SUPABASE_ANON_KEY=your-anon-key
```

3. Wrap your app with providers:
```tsx
import { AuthProvider } from './contexts/AuthContext';
import { ToastProvider } from './components/ui/Toast';

function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <YourApp />
      </ToastProvider>
    </AuthProvider>
  );
}
```

4. Use role-based components:
```tsx
import { PermissionGate, RoleGate } from './components/common/RoleBasedAccess';
import { PERMISSIONS } from './types/auth.types';

// Hide button if user lacks permission
<PermissionGate permission={PERMISSIONS.SORT_FINDINGS}>
  <SortButton />
</PermissionGate>
```

---

## Summary of Changes

| Improvement | Status | Key Files |
|-------------|--------|-----------|
| 1. Multi-DB Connections | ✅ Complete | `data-source-manager.ts` |
| 2. Real-Time Insights | ✅ Complete | `insights-engine.ts` |
| 3. UX/UI (File Upload, Toasts) | ✅ Complete | `FileUpload.tsx`, `Toast.tsx` |
| 4. Accessibility | ✅ Complete | All UI components |
| 5. UI Consistency | ✅ Complete | `Button.tsx` + design system |
| 6. RBAC (Hide Unauthorized) | ✅ Complete | `RoleBasedAccess.tsx`, demo pages |

---

## Testing Role-Based Access

To test how different roles see different UI elements:

1. In `AuthContext.tsx`, modify the mock user:
```typescript
// Try different roles:
const mockUser: User = {
  id: '1',
  email: 'user@example.com',
  name: 'Test User',
  role: 'viewer', // Change this to: 'admin', 'maintenance_team_leader', etc.
  isActive: true,
  createdAt: new Date(),
};
```

2. Observe how the Findings and Reports pages change:
   - **Admin**: Sees all buttons (Create, Sort, Assign, Close, Delete, etc.)
   - **Maintenance Team Leader**: Sees Sort, Assign, Close buttons
   - **Technician**: Sees Create, Edit buttons only
   - **Viewer**: Sees no action buttons, read-only view

This ensures that **unauthorized functions are completely hidden**, not just disabled!
