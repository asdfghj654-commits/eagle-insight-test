// ============================================================================
// Eagle Insight - Data Source Types & Manager
// Improvement #1: Managing Connections to Multiple SQL Databases
// ============================================================================

export type DatabaseType = 'postgresql' | 'mysql' | 'mssql' | 'sqlite' | 'oracle';

export interface SQLDataSourceConfig {
  id: string;
  name: string;
  type: DatabaseType;
  host: string;
  port: number;
  database: string;
  username: string;
  password: string;
  ssl?: boolean;
  connectionTimeout?: number;
  maxPoolSize?: number;
  minPoolSize?: number;
  idleTimeout?: number;
  schema?: string;
  options?: Record<string, unknown>;
}

export interface ConnectionStatus {
  id: string;
  isConnected: boolean;
  lastConnected?: Date;
  lastError?: string;
  activeConnections: number;
  poolSize: number;
}

export interface DataSourceConnection {
  config: SQLDataSourceConfig;
  status: ConnectionStatus;
  connect: () => Promise<void>;
  disconnect: () => Promise<void>;
  query: <T>(sql: string, params?: unknown[]) => Promise<T[]>;
  healthCheck: () => Promise<boolean>;
}

export interface DataSourceManagerEvents {
  onConnect: (dataSourceId: string) => void;
  onDisconnect: (dataSourceId: string) => void;
  onError: (dataSourceId: string, error: Error) => void;
  onHealthCheckFailed: (dataSourceId: string) => void;
}

/**
 * DataSourceManager - Manages multiple SQL database connections
 * 
 * This class provides a flexible way to:
 * - Add and remove multiple database connections
 * - Connect/disconnect from databases dynamically
 * - Monitor connection health
 * - Handle connection pooling
 */
export class DataSourceManager {
  private dataSources: Map<string, SQLDataSourceConfig> = new Map();
  private connections: Map<string, DataSourceConnection> = new Map();
  private connectionStatuses: Map<string, ConnectionStatus> = new Map();
  private eventHandlers: Partial<DataSourceManagerEvents> = {};
  private healthCheckIntervals: Map<string, NodeJS.Timeout> = new Map();

  constructor(private defaultOptions: Partial<SQLDataSourceConfig> = {}) {
    this.defaultOptions = {
      connectionTimeout: 30000,
      maxPoolSize: 10,
      minPoolSize: 2,
      idleTimeout: 60000,
      ssl: true,
      ...defaultOptions,
    };
  }

  /**
   * Register event handlers for connection events
   */
  public on<K extends keyof DataSourceManagerEvents>(
    event: K,
    handler: DataSourceManagerEvents[K]
  ): void {
    this.eventHandlers[event] = handler;
  }

  /**
   * Add a new data source configuration
   */
  public addDataSource(key: string, config: SQLDataSourceConfig): void {
    const mergedConfig: SQLDataSourceConfig = {
      ...this.defaultOptions,
      ...config,
      id: key,
    } as SQLDataSourceConfig;

    this.dataSources.set(key, mergedConfig);
    this.connectionStatuses.set(key, {
      id: key,
      isConnected: false,
      activeConnections: 0,
      poolSize: 0,
    });
  }

  /**
   * Remove a data source and close its connection
   */
  public async removeDataSource(key: string): Promise<void> {
    await this.disconnectDataSource(key);
    this.dataSources.delete(key);
    this.connectionStatuses.delete(key);
    
    const healthCheckInterval = this.healthCheckIntervals.get(key);
    if (healthCheckInterval) {
      clearInterval(healthCheckInterval);
      this.healthCheckIntervals.delete(key);
    }
  }

  /**
   * Get a data source configuration by key
   */
  public getDataSource(key: string): SQLDataSourceConfig | undefined {
    return this.dataSources.get(key);
  }

  /**
   * Get all data source configurations
   */
  public getAllDataSources(): Map<string, SQLDataSourceConfig> {
    return new Map(this.dataSources);
  }

  /**
   * Get connection status for a specific data source
   */
  public getConnectionStatus(key: string): ConnectionStatus | undefined {
    return this.connectionStatuses.get(key);
  }

  /**
   * Get all connection statuses
   */
  public getAllConnectionStatuses(): Map<string, ConnectionStatus> {
    return new Map(this.connectionStatuses);
  }

  /**
   * Connect to a specific data source
   */
  public async connectDataSource(key: string): Promise<void> {
    const config = this.dataSources.get(key);
    if (!config) {
      throw new Error(`Data source "${key}" not found`);
    }

    try {
      // Create connection based on database type
      const connection = await this.createConnection(config);
      this.connections.set(key, connection);
      
      this.updateConnectionStatus(key, {
        isConnected: true,
        lastConnected: new Date(),
        activeConnections: 1,
        poolSize: config.maxPoolSize || 10,
      });

      this.eventHandlers.onConnect?.(key);
      this.startHealthCheck(key);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      this.updateConnectionStatus(key, {
        isConnected: false,
        lastError: errorMessage,
      });
      this.eventHandlers.onError?.(key, error as Error);
      throw error;
    }
  }

  /**
   * Disconnect from a specific data source
   */
  public async disconnectDataSource(key: string): Promise<void> {
    const connection = this.connections.get(key);
    if (connection) {
      await connection.disconnect();
      this.connections.delete(key);
      this.updateConnectionStatus(key, {
        isConnected: false,
        activeConnections: 0,
      });
      this.eventHandlers.onDisconnect?.(key);
    }
  }

  /**
   * Connect to all configured data sources
   */
  public async connectToAllDatabases(): Promise<Map<string, boolean>> {
    const results = new Map<string, boolean>();
    
    const connectionPromises = Array.from(this.dataSources.keys()).map(async (key) => {
      try {
        await this.connectDataSource(key);
        results.set(key, true);
      } catch {
        results.set(key, false);
      }
    });

    await Promise.allSettled(connectionPromises);
    return results;
  }

  /**
   * Disconnect from all data sources
   */
  public async disconnectAll(): Promise<void> {
    const disconnectPromises = Array.from(this.connections.keys()).map((key) =>
      this.disconnectDataSource(key)
    );
    await Promise.allSettled(disconnectPromises);
  }

  /**
   * Execute a query on a specific data source
   */
  public async query<T>(
    dataSourceKey: string,
    sql: string,
    params?: unknown[]
  ): Promise<T[]> {
    const connection = this.connections.get(dataSourceKey);
    if (!connection) {
      throw new Error(`No active connection for data source "${dataSourceKey}"`);
    }
    return connection.query<T>(sql, params);
  }

  /**
   * Execute a query across multiple data sources
   */
  public async queryMultiple<T>(
    dataSourceKeys: string[],
    sql: string,
    params?: unknown[]
  ): Promise<Map<string, T[]>> {
    const results = new Map<string, T[]>();
    
    const queryPromises = dataSourceKeys.map(async (key) => {
      try {
        const result = await this.query<T>(key, sql, params);
        results.set(key, result);
      } catch (error) {
        console.error(`Query failed for data source "${key}":`, error);
        results.set(key, []);
      }
    });

    await Promise.allSettled(queryPromises);
    return results;
  }

  /**
   * Check health of all connections
   */
  public async healthCheckAll(): Promise<Map<string, boolean>> {
    const results = new Map<string, boolean>();
    
    const healthCheckPromises = Array.from(this.connections.entries()).map(
      async ([key, connection]) => {
        try {
          const isHealthy = await connection.healthCheck();
          results.set(key, isHealthy);
          if (!isHealthy) {
            this.eventHandlers.onHealthCheckFailed?.(key);
          }
        } catch {
          results.set(key, false);
          this.eventHandlers.onHealthCheckFailed?.(key);
        }
      }
    );

    await Promise.allSettled(healthCheckPromises);
    return results;
  }

  // Private methods

  private async createConnection(
    config: SQLDataSourceConfig
  ): Promise<DataSourceConnection> {
    // This would be replaced with actual database driver implementations
    // For now, returning a mock connection structure
    return {
      config,
      status: {
        id: config.id,
        isConnected: true,
        activeConnections: 1,
        poolSize: config.maxPoolSize || 10,
      },
      connect: async () => {
        console.log(`Connecting to ${config.type} database: ${config.name}`);
      },
      disconnect: async () => {
        console.log(`Disconnecting from ${config.type} database: ${config.name}`);
      },
      query: async <T>(_sql: string, _params?: unknown[]): Promise<T[]> => {
        return [] as T[];
      },
      healthCheck: async () => true,
    };
  }

  private updateConnectionStatus(
    key: string,
    updates: Partial<ConnectionStatus>
  ): void {
    const currentStatus = this.connectionStatuses.get(key);
    if (currentStatus) {
      this.connectionStatuses.set(key, { ...currentStatus, ...updates });
    }
  }

  private startHealthCheck(key: string, intervalMs: number = 30000): void {
    const existingInterval = this.healthCheckIntervals.get(key);
    if (existingInterval) {
      clearInterval(existingInterval);
    }

    const interval = setInterval(async () => {
      const connection = this.connections.get(key);
      if (connection) {
        try {
          const isHealthy = await connection.healthCheck();
          if (!isHealthy) {
            this.eventHandlers.onHealthCheckFailed?.(key);
          }
        } catch {
          this.eventHandlers.onHealthCheckFailed?.(key);
        }
      }
    }, intervalMs);

    this.healthCheckIntervals.set(key, interval);
  }
}

// Export singleton instance
export const dataSourceManager = new DataSourceManager();

// Helper function to configure multiple data sources
export function configureDataSources(
  configs: SQLDataSourceConfig[]
): DataSourceManager {
  const manager = new DataSourceManager();
  configs.forEach((config) => {
    manager.addDataSource(config.id, config);
  });
  return manager;
}
