// ============================================================================
// Eagle Insight - Button Component
// Improvement #4 & #5: Accessibility & UI Consistency
// ============================================================================

import React, { forwardRef, ButtonHTMLAttributes, ReactNode } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../../lib/utils';

// Button variants using class-variance-authority for consistent styling
const buttonVariants = cva(
  // Base styles
  [
    'inline-flex items-center justify-center gap-2',
    'whitespace-nowrap rounded-md text-sm font-medium',
    'transition-all duration-200 ease-in-out',
    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2',
    'disabled:pointer-events-none disabled:opacity-50',
    'select-none',
  ],
  {
    variants: {
      variant: {
        primary: [
          'bg-blue-600 text-white',
          'hover:bg-blue-700 active:bg-blue-800',
          'focus-visible:ring-blue-500',
          'shadow-sm hover:shadow-md',
        ],
        secondary: [
          'bg-gray-100 text-gray-900',
          'hover:bg-gray-200 active:bg-gray-300',
          'focus-visible:ring-gray-400',
          'border border-gray-300',
        ],
        danger: [
          'bg-red-600 text-white',
          'hover:bg-red-700 active:bg-red-800',
          'focus-visible:ring-red-500',
          'shadow-sm hover:shadow-md',
        ],
        warning: [
          'bg-amber-500 text-white',
          'hover:bg-amber-600 active:bg-amber-700',
          'focus-visible:ring-amber-400',
          'shadow-sm hover:shadow-md',
        ],
        success: [
          'bg-emerald-600 text-white',
          'hover:bg-emerald-700 active:bg-emerald-800',
          'focus-visible:ring-emerald-500',
          'shadow-sm hover:shadow-md',
        ],
        ghost: [
          'bg-transparent text-gray-700',
          'hover:bg-gray-100 active:bg-gray-200',
          'focus-visible:ring-gray-400',
        ],
        link: [
          'bg-transparent text-blue-600 underline-offset-4',
          'hover:underline hover:text-blue-700',
          'focus-visible:ring-blue-500',
          'p-0 h-auto',
        ],
        outline: [
          'bg-transparent text-gray-700',
          'border-2 border-gray-300',
          'hover:bg-gray-50 hover:border-gray-400',
          'active:bg-gray-100',
          'focus-visible:ring-gray-400',
        ],
        outlinePrimary: [
          'bg-transparent text-blue-600',
          'border-2 border-blue-500',
          'hover:bg-blue-50 hover:border-blue-600',
          'active:bg-blue-100',
          'focus-visible:ring-blue-500',
        ],
      },
      size: {
        xs: 'h-7 px-2 text-xs rounded',
        sm: 'h-8 px-3 text-sm rounded-md',
        md: 'h-10 px-4 text-sm rounded-md',
        lg: 'h-12 px-6 text-base rounded-lg',
        xl: 'h-14 px-8 text-lg rounded-lg',
        icon: 'h-10 w-10 p-0',
        iconSm: 'h-8 w-8 p-0',
        iconLg: 'h-12 w-12 p-0',
      },
      fullWidth: {
        true: 'w-full',
        false: '',
      },
    },
    defaultVariants: {
      variant: 'primary',
      size: 'md',
      fullWidth: false,
    },
  }
);

// Loading spinner component
function LoadingSpinner({ className }: { className?: string }) {
  return (
    <svg
      className={cn('animate-spin', className)}
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 24 24"
      aria-hidden="true"
    >
      <circle
        className="opacity-25"
        cx="12"
        cy="12"
        r="10"
        stroke="currentColor"
        strokeWidth="4"
      />
      <path
        className="opacity-75"
        fill="currentColor"
        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
      />
    </svg>
  );
}

export interface ButtonProps
  extends ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  /** Shows a loading spinner and disables the button */
  isLoading?: boolean;
  /** Text to show when loading (defaults to children) */
  loadingText?: string;
  /** Icon to display before the button text */
  leftIcon?: ReactNode;
  /** Icon to display after the button text */
  rightIcon?: ReactNode;
  /** Accessible label for the button (required for icon-only buttons) */
  'aria-label'?: string;
}

/**
 * Button - Accessible, consistently styled button component
 * 
 * @example
 * // Primary button
 * <Button onClick={handleClick}>Save Changes</Button>
 * 
 * @example
 * // Loading state
 * <Button isLoading loadingText="Saving...">Save</Button>
 * 
 * @example
 * // With icons
 * <Button leftIcon={<PlusIcon />}>Add Item</Button>
 * 
 * @example
 * // Icon-only button (requires aria-label)
 * <Button variant="ghost" size="icon" aria-label="Delete item">
 *   <TrashIcon />
 * </Button>
 */
const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      className,
      variant,
      size,
      fullWidth,
      isLoading = false,
      loadingText,
      leftIcon,
      rightIcon,
      disabled,
      children,
      type = 'button',
      'aria-label': ariaLabel,
      ...props
    },
    ref
  ) => {
    const isDisabled = disabled || isLoading;

    // Warn if icon-only button is missing aria-label
    if (process.env.NODE_ENV === 'development') {
      const isIconButton = size === 'icon' || size === 'iconSm' || size === 'iconLg';
      if (isIconButton && !ariaLabel && !children) {
        console.warn(
          'Button: Icon-only buttons require an aria-label for accessibility.'
        );
      }
    }

    return (
      <button
        ref={ref}
        type={type}
        className={cn(buttonVariants({ variant, size, fullWidth }), className)}
        disabled={isDisabled}
        aria-disabled={isDisabled}
        aria-busy={isLoading}
        aria-label={ariaLabel}
        {...props}
      >
        {isLoading ? (
          <>
            <LoadingSpinner className="h-4 w-4" />
            <span>{loadingText || children}</span>
          </>
        ) : (
          <>
            {leftIcon && (
              <span className="inline-flex shrink-0" aria-hidden="true">
                {leftIcon}
              </span>
            )}
            {children && <span>{children}</span>}
            {rightIcon && (
              <span className="inline-flex shrink-0" aria-hidden="true">
                {rightIcon}
              </span>
            )}
          </>
        )}
      </button>
    );
  }
);

Button.displayName = 'Button';

export { Button, buttonVariants };

// Convenience exports for common button patterns
export function PrimaryButton(props: ButtonProps) {
  return <Button variant="primary" {...props} />;
}

export function SecondaryButton(props: ButtonProps) {
  return <Button variant="secondary" {...props} />;
}

export function DangerButton(props: ButtonProps) {
  return <Button variant="danger" {...props} />;
}

export function SuccessButton(props: ButtonProps) {
  return <Button variant="success" {...props} />;
}

export function IconButton(props: ButtonProps) {
  return <Button variant="ghost" size="icon" {...props} />;
}
