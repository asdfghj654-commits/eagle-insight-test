// ============================================================================
// Eagle Insight - File Upload Component
// Improvement #3: UX/UI Improvements for File Upload
// ============================================================================

import React, { useState, useRef, useCallback, DragEvent, ChangeEvent } from 'react';
import { cn } from '../../lib/utils';
import { Button } from './Button';
import { useToast } from './Toast';

export interface FileUploadConfig {
  /** Accepted file types (e.g., '.csv', '.xlsx', 'image/*') */
  accept?: string | string[];
  /** Maximum file size in bytes */
  maxSize?: number;
  /** Maximum number of files (1 for single file upload) */
  maxFiles?: number;
  /** Whether multiple files are allowed */
  multiple?: boolean;
  /** Custom validation function */
  validate?: (file: File) => { valid: boolean; error?: string };
}

export interface UploadedFile {
  id: string;
  file: File;
  name: string;
  size: number;
  type: string;
  progress: number;
  status: 'pending' | 'uploading' | 'success' | 'error';
  error?: string;
  preview?: string;
}

interface FileUploadProps extends FileUploadConfig {
  /** Callback when files are selected/dropped */
  onFilesSelected?: (files: File[]) => void;
  /** Callback when upload completes for a file */
  onUploadComplete?: (file: UploadedFile) => void;
  /** Callback when upload fails for a file */
  onUploadError?: (file: UploadedFile, error: string) => void;
  /** Callback when a file is removed */
  onFileRemove?: (file: UploadedFile) => void;
  /** Upload handler function */
  uploadHandler?: (file: File, onProgress: (progress: number) => void) => Promise<void>;
  /** Additional CSS classes */
  className?: string;
  /** Disabled state */
  disabled?: boolean;
  /** Label text */
  label?: string;
  /** Helper text */
  helperText?: string;
  /** ID for accessibility */
  id?: string;
}

// Format bytes to human-readable size
function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Get file extension
function getFileExtension(filename: string): string {
  return filename.slice(((filename.lastIndexOf('.') - 1) >>> 0) + 2).toLowerCase();
}

// Check if file type is accepted
function isFileTypeAccepted(file: File, accept?: string | string[]): boolean {
  if (!accept) return true;
  
  const acceptList = Array.isArray(accept) ? accept : accept.split(',').map(s => s.trim());
  const fileExtension = '.' + getFileExtension(file.name);
  const mimeType = file.type;

  return acceptList.some(acceptType => {
    if (acceptType.startsWith('.')) {
      return fileExtension === acceptType.toLowerCase();
    }
    if (acceptType.endsWith('/*')) {
      const category = acceptType.split('/')[0];
      return mimeType.startsWith(category + '/');
    }
    return mimeType === acceptType;
  });
}

// File type icon component
function FileTypeIcon({ type, className }: { type: string; className?: string }) {
  const iconClass = cn('w-8 h-8', className);
  
  if (type.startsWith('image/')) {
    return (
      <svg className={iconClass} fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} 
          d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
      </svg>
    );
  }
  
  if (type.includes('spreadsheet') || type.includes('excel') || type.includes('csv')) {
    return (
      <svg className={cn(iconClass, 'text-emerald-600')} fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
          d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
      </svg>
    );
  }
  
  return (
    <svg className={iconClass} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
        d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
    </svg>
  );
}

export function FileUpload({
  accept,
  maxSize = 10 * 1024 * 1024, // 10MB default
  maxFiles = 5,
  multiple = false,
  validate,
  onFilesSelected,
  onUploadComplete,
  onUploadError,
  onFileRemove,
  uploadHandler,
  className,
  disabled = false,
  label = 'Upload files',
  helperText,
  id = 'file-upload',
}: FileUploadProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const toast = useToast();

  // Format accepted file types for display
  const acceptedTypesDisplay = accept
    ? (Array.isArray(accept) ? accept : accept.split(',')).map(t => t.trim()).join(', ')
    : 'All file types';

  // Validate a single file
  const validateFile = useCallback((file: File): { valid: boolean; error?: string } => {
    // Check file type
    if (!isFileTypeAccepted(file, accept)) {
      return { valid: false, error: `File type not accepted. Allowed: ${acceptedTypesDisplay}` };
    }

    // Check file size
    if (file.size > maxSize) {
      return { valid: false, error: `File too large. Maximum size: ${formatFileSize(maxSize)}` };
    }

    // Custom validation
    if (validate) {
      return validate(file);
    }

    return { valid: true };
  }, [accept, maxSize, validate, acceptedTypesDisplay]);

  // Process selected files
  const processFiles = useCallback(async (selectedFiles: FileList | File[]) => {
    const fileArray = Array.from(selectedFiles);
    
    // Check max files limit
    const availableSlots = maxFiles - files.length;
    if (fileArray.length > availableSlots) {
      toast.warning(`Only ${availableSlots} more file(s) can be added. Maximum: ${maxFiles}`);
      fileArray.splice(availableSlots);
    }

    const newFiles: UploadedFile[] = [];

    for (const file of fileArray) {
      const validation = validateFile(file);
      
      const uploadedFile: UploadedFile = {
        id: crypto.randomUUID(),
        file,
        name: file.name,
        size: file.size,
        type: file.type,
        progress: 0,
        status: validation.valid ? 'pending' : 'error',
        error: validation.error,
      };

      // Create preview for images
      if (file.type.startsWith('image/') && validation.valid) {
        try {
          uploadedFile.preview = await createImagePreview(file);
        } catch {
          // Preview creation failed, continue without preview
        }
      }

      if (!validation.valid) {
        toast.error(validation.error || 'File validation failed');
      }

      newFiles.push(uploadedFile);
    }

    setFiles(prev => [...prev, ...newFiles]);
    
    const validFiles = newFiles.filter(f => f.status === 'pending').map(f => f.file);
    if (validFiles.length > 0) {
      onFilesSelected?.(validFiles);
      toast.success(`${validFiles.length} file(s) added successfully`);
      
      // Auto-upload if handler is provided
      if (uploadHandler) {
        for (const uploadedFile of newFiles.filter(f => f.status === 'pending')) {
          uploadFile(uploadedFile);
        }
      }
    }
  }, [files.length, maxFiles, validateFile, onFilesSelected, uploadHandler, toast]);

  // Create image preview
  const createImagePreview = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  // Upload a single file
  const uploadFile = async (uploadedFile: UploadedFile) => {
    if (!uploadHandler) return;

    setFiles(prev => prev.map(f => 
      f.id === uploadedFile.id ? { ...f, status: 'uploading' as const } : f
    ));

    try {
      await uploadHandler(uploadedFile.file, (progress) => {
        setFiles(prev => prev.map(f =>
          f.id === uploadedFile.id ? { ...f, progress } : f
        ));
      });

      setFiles(prev => prev.map(f =>
        f.id === uploadedFile.id ? { ...f, status: 'success' as const, progress: 100 } : f
      ));

      const updatedFile = { ...uploadedFile, status: 'success' as const, progress: 100 };
      onUploadComplete?.(updatedFile);
      toast.success(`${uploadedFile.name} uploaded successfully`);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Upload failed';
      
      setFiles(prev => prev.map(f =>
        f.id === uploadedFile.id ? { ...f, status: 'error' as const, error: errorMessage } : f
      ));

      const updatedFile = { ...uploadedFile, status: 'error' as const, error: errorMessage };
      onUploadError?.(updatedFile, errorMessage);
      toast.error(`Failed to upload ${uploadedFile.name}: ${errorMessage}`);
    }
  };

  // Remove a file
  const removeFile = (file: UploadedFile) => {
    setFiles(prev => prev.filter(f => f.id !== file.id));
    onFileRemove?.(file);
    
    // Revoke preview URL to prevent memory leaks
    if (file.preview) {
      URL.revokeObjectURL(file.preview);
    }
  };

  // Retry failed upload
  const retryUpload = (file: UploadedFile) => {
    const resetFile = { ...file, status: 'pending' as const, error: undefined, progress: 0 };
    setFiles(prev => prev.map(f => f.id === file.id ? resetFile : f));
    
    if (uploadHandler) {
      uploadFile(resetFile);
    }
  };

  // Handle file input change
  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFiles(e.target.files);
      // Reset input
      e.target.value = '';
    }
  };

  // Handle drag events
  const handleDragOver = (e: DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!disabled) {
      setIsDragOver(true);
    }
  };

  const handleDragLeave = (e: DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
  };

  const handleDrop = (e: DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);

    if (disabled) return;

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files);
    }
  };

  // Open file dialog
  const openFileDialog = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className={cn('w-full', className)}>
      {/* Label */}
      <label
        htmlFor={id}
        className="block text-sm font-medium text-gray-700 mb-2"
      >
        {label}
      </label>

      {/* Drop zone */}
      <div
        role="button"
        tabIndex={disabled ? -1 : 0}
        aria-label={`${label}. ${helperText || ''} Accepted types: ${acceptedTypesDisplay}`}
        aria-disabled={disabled}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={disabled ? undefined : openFileDialog}
        onKeyDown={(e) => {
          if ((e.key === 'Enter' || e.key === ' ') && !disabled) {
            e.preventDefault();
            openFileDialog();
          }
        }}
        className={cn(
          'relative flex flex-col items-center justify-center',
          'w-full min-h-[160px] p-6',
          'border-2 border-dashed rounded-lg',
          'transition-all duration-200 ease-in-out',
          'cursor-pointer',
          'focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2',
          isDragOver && !disabled && 'border-blue-500 bg-blue-50',
          !isDragOver && !disabled && 'border-gray-300 hover:border-gray-400 bg-gray-50 hover:bg-gray-100',
          disabled && 'cursor-not-allowed opacity-50 bg-gray-100'
        )}
      >
        {/* Upload icon */}
        <svg
          className={cn(
            'w-12 h-12 mb-4 transition-colors',
            isDragOver ? 'text-blue-500' : 'text-gray-400'
          )}
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
          aria-hidden="true"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.5}
            d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
          />
        </svg>

        {/* Text */}
        <div className="text-center">
          <p className="text-sm text-gray-600">
            <span className="font-semibold text-blue-600 hover:text-blue-700">
              Click to upload
            </span>
            {' '}or drag and drop
          </p>
          <p className="mt-1 text-xs text-gray-500">
            {acceptedTypesDisplay} (max {formatFileSize(maxSize)})
          </p>
        </div>

        {/* Hidden file input */}
        <input
          ref={fileInputRef}
          type="file"
          id={id}
          className="sr-only"
          accept={Array.isArray(accept) ? accept.join(',') : accept}
          multiple={multiple}
          disabled={disabled}
          onChange={handleInputChange}
          aria-describedby={helperText ? `${id}-helper` : undefined}
        />
      </div>

      {/* Helper text */}
      {helperText && (
        <p id={`${id}-helper`} className="mt-2 text-sm text-gray-500">
          {helperText}
        </p>
      )}

      {/* File list */}
      {files.length > 0 && (
        <ul className="mt-4 space-y-2" aria-label="Uploaded files">
          {files.map((file) => (
            <li
              key={file.id}
              className={cn(
                'flex items-center gap-3 p-3 rounded-lg border',
                file.status === 'error' && 'border-red-200 bg-red-50',
                file.status === 'success' && 'border-emerald-200 bg-emerald-50',
                file.status === 'uploading' && 'border-blue-200 bg-blue-50',
                file.status === 'pending' && 'border-gray-200 bg-white'
              )}
            >
              {/* Preview or icon */}
              {file.preview ? (
                <img
                  src={file.preview}
                  alt={`Preview of ${file.name}`}
                  className="w-10 h-10 object-cover rounded"
                />
              ) : (
                <FileTypeIcon type={file.type} className="text-gray-400" />
              )}

              {/* File info */}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">
                  {file.name}
                </p>
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <span>{formatFileSize(file.size)}</span>
                  {file.status === 'uploading' && (
                    <span className="text-blue-600">{file.progress}%</span>
                  )}
                  {file.status === 'success' && (
                    <span className="text-emerald-600">✓ Uploaded</span>
                  )}
                  {file.status === 'error' && (
                    <span className="text-red-600">{file.error}</span>
                  )}
                </div>

                {/* Progress bar */}
                {file.status === 'uploading' && (
                  <div className="mt-1 w-full h-1.5 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-600 transition-all duration-300"
                      style={{ width: `${file.progress}%` }}
                      role="progressbar"
                      aria-valuenow={file.progress}
                      aria-valuemin={0}
                      aria-valuemax={100}
                      aria-label={`Upload progress: ${file.progress}%`}
                    />
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex items-center gap-1">
                {file.status === 'error' && uploadHandler && (
                  <Button
                    variant="ghost"
                    size="iconSm"
                    onClick={() => retryUpload(file)}
                    aria-label={`Retry uploading ${file.name}`}
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                        d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                    </svg>
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="iconSm"
                  onClick={() => removeFile(file)}
                  aria-label={`Remove ${file.name}`}
                >
                  <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                      d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

// Convenience component for CSV-only uploads
export function CSVUpload(props: Omit<FileUploadProps, 'accept'>) {
  return (
    <FileUpload
      {...props}
      accept=".csv"
      label={props.label || 'Upload CSV file'}
      helperText={props.helperText || 'Only CSV files are accepted'}
    />
  );
}

// Convenience component for image uploads
export function ImageUpload(props: Omit<FileUploadProps, 'accept'>) {
  return (
    <FileUpload
      {...props}
      accept="image/*"
      label={props.label || 'Upload image'}
      helperText={props.helperText || 'PNG, JPG, GIF up to 10MB'}
    />
  );
}
