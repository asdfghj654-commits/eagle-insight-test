// ============================================================================
// Eagle Insight - Role-Based Access Control Components
// Improvement #6: Hide unauthorized functions from UI
// ============================================================================

import React, { ReactNode } from 'react';
import { useAuth, useFeatureAccess, FeatureKey } from '../contexts/AuthContext';
import { UserRole } from '../types/auth.types';

interface PermissionGateProps {
  /** Required permission(s) to render children */
  permission?: string | string[];
  /** Require all permissions (AND) or any permission (OR) */
  requireAll?: boolean;
  /** Content to render if authorized */
  children: ReactNode;
  /** Optional fallback content for unauthorized users */
  fallback?: ReactNode;
}

/**
 * PermissionGate - Conditionally renders content based on user permissions
 * 
 * @example
 * // Single permission
 * <PermissionGate permission="sort_findings">
 *   <SortFindingsButton />
 * </PermissionGate>
 * 
 * @example
 * // Multiple permissions (OR)
 * <PermissionGate permission={['edit_findings', 'delete_findings']}>
 *   <FindingsActionMenu />
 * </PermissionGate>
 * 
 * @example
 * // Multiple permissions (AND)
 * <PermissionGate permission={['create_reports', 'export_reports']} requireAll>
 *   <GenerateReportButton />
 * </PermissionGate>
 */
export function PermissionGate({
  permission,
  requireAll = false,
  children,
  fallback = null,
}: PermissionGateProps): ReactNode {
  const { hasPermission, hasAnyPermission, hasAllPermissions, isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return fallback;
  }

  if (!permission) {
    return children;
  }

  const permissions = Array.isArray(permission) ? permission : [permission];
  const hasAccess = requireAll
    ? hasAllPermissions(permissions)
    : permissions.length === 1
    ? hasPermission(permissions[0])
    : hasAnyPermission(permissions);

  return hasAccess ? children : fallback;
}

interface RoleGateProps {
  /** Required role(s) to render children */
  role: UserRole | UserRole[];
  /** Content to render if authorized */
  children: ReactNode;
  /** Optional fallback content for unauthorized users */
  fallback?: ReactNode;
}

/**
 * RoleGate - Conditionally renders content based on user role
 * 
 * @example
 * // Single role
 * <RoleGate role="admin">
 *   <AdminPanel />
 * </RoleGate>
 * 
 * @example
 * // Multiple roles (OR)
 * <RoleGate role={['admin', 'maintenance_team_leader']}>
 *   <TeamLeaderReports />
 * </RoleGate>
 */
export function RoleGate({ role, children, fallback = null }: RoleGateProps): ReactNode {
  const { hasRole, hasAnyRole, isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return fallback;
  }

  const roles = Array.isArray(role) ? role : [role];
  const hasAccess = roles.length === 1 ? hasRole(roles[0]) : hasAnyRole(roles);

  return hasAccess ? children : fallback;
}

interface FeatureGateProps {
  /** Feature key to check access for */
  feature: FeatureKey;
  /** Content to render if authorized */
  children: ReactNode;
  /** Optional fallback content for unauthorized users */
  fallback?: ReactNode;
}

/**
 * FeatureGate - Conditionally renders content based on feature access
 * 
 * @example
 * <FeatureGate feature="findings_sort">
 *   <SortFindingsButton />
 * </FeatureGate>
 */
export function FeatureGate({ feature, children, fallback = null }: FeatureGateProps): ReactNode {
  const hasAccess = useFeatureAccess(feature);

  return hasAccess ? children : fallback;
}

interface AuthenticatedOnlyProps {
  children: ReactNode;
  fallback?: ReactNode;
}

/**
 * AuthenticatedOnly - Only renders content for authenticated users
 */
export function AuthenticatedOnly({ children, fallback = null }: AuthenticatedOnlyProps): ReactNode {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? children : fallback;
}

interface UnauthorizedMessageProps {
  message?: string;
  showContactAdmin?: boolean;
}

/**
 * UnauthorizedMessage - Standard message for unauthorized access attempts
 */
export function UnauthorizedMessage({
  message = "You don't have permission to access this feature.",
  showContactAdmin = true,
}: UnauthorizedMessageProps): JSX.Element {
  return (
    <div
      className="flex flex-col items-center justify-center p-8 text-center"
      role="alert"
      aria-live="polite"
    >
      <div className="w-16 h-16 mb-4 rounded-full bg-amber-100 flex items-center justify-center">
        <svg
          className="w-8 h-8 text-amber-600"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
          aria-hidden="true"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M12 15v2m0 0v2m0-2h2m-2 0H10m2-6V4a2 2 0 00-2-2H8a2 2 0 00-2 2v5"
          />
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M5 12h14l-1.5 9h-11L5 12z"
          />
        </svg>
      </div>
      <h3 className="text-lg font-semibold text-gray-900 mb-2">Access Restricted</h3>
      <p className="text-gray-600 max-w-md">{message}</p>
      {showContactAdmin && (
        <p className="text-sm text-gray-500 mt-2">
          Contact your administrator if you believe you should have access.
        </p>
      )}
    </div>
  );
}

// Higher-order component version for class components or route protection
export function withPermission<P extends object>(
  WrappedComponent: React.ComponentType<P>,
  permission: string | string[],
  requireAll = false
) {
  return function WithPermissionComponent(props: P) {
    return (
      <PermissionGate
        permission={permission}
        requireAll={requireAll}
        fallback={<UnauthorizedMessage />}
      >
        <WrappedComponent {...props} />
      </PermissionGate>
    );
  };
}

export function withRole<P extends object>(
  WrappedComponent: React.ComponentType<P>,
  role: UserRole | UserRole[]
) {
  return function WithRoleComponent(props: P) {
    return (
      <RoleGate role={role} fallback={<UnauthorizedMessage />}>
        <WrappedComponent {...props} />
      </RoleGate>
    );
  };
}

export function withFeatureAccess<P extends object>(
  WrappedComponent: React.ComponentType<P>,
  feature: FeatureKey
) {
  return function WithFeatureAccessComponent(props: P) {
    return (
      <FeatureGate feature={feature} fallback={<UnauthorizedMessage />}>
        <WrappedComponent {...props} />
      </FeatureGate>
    );
  };
}
