// ============================================================================
// Eagle Insight - Reports Page
// Demonstrates role-based report visibility - maintenance team leader reports
// are only visible to authorized users
// ============================================================================

import React, { useState } from 'react';
import { Button } from '../ui/Button';
import { useToast } from '../ui/Toast';
import { useAuth } from '../../contexts/AuthContext';
import { 
  PermissionGate, 
  FeatureGate, 
  RoleGate,
  UnauthorizedMessage 
} from '../common/RoleBasedAccess';
import { PERMISSIONS, ROLE_DISPLAY_NAMES } from '../../types/auth.types';
import { cn, formatDate } from '../../lib/utils';

// Types
interface Report {
  id: string;
  title: string;
  description: string;
  type: ReportType;
  status: 'draft' | 'published' | 'archived';
  created_by: string;
  created_at: Date;
  updated_at: Date;
  required_role?: string[];
}

type ReportType = 
  | 'maintenance_summary'
  | 'team_leader_review'
  | 'compliance_audit'
  | 'fleet_status'
  | 'performance_analysis'
  | 'safety_inspection';

// Report type configuration
const reportTypeConfig: Record<ReportType, { 
  label: string; 
  color: string; 
  icon: React.ReactNode;
  requiredRoles?: string[];
}> = {
  maintenance_summary: {
    label: 'Maintenance Summary',
    color: 'bg-blue-100 text-blue-800',
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
          d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
      </svg>
    ),
  },
  team_leader_review: {
    label: 'Team Leader Review',
    color: 'bg-purple-100 text-purple-800',
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
          d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
      </svg>
    ),
    requiredRoles: ['admin', 'maintenance_team_leader'],
  },
  compliance_audit: {
    label: 'Compliance Audit',
    color: 'bg-red-100 text-red-800',
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
          d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
      </svg>
    ),
    requiredRoles: ['admin', 'maintenance_team_leader', 'quality_inspector'],
  },
  fleet_status: {
    label: 'Fleet Status',
    color: 'bg-green-100 text-green-800',
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
          d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064" />
      </svg>
    ),
  },
  performance_analysis: {
    label: 'Performance Analysis',
    color: 'bg-orange-100 text-orange-800',
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
          d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
      </svg>
    ),
    requiredRoles: ['admin', 'maintenance_team_leader', 'quality_inspector', 'flight_operations'],
  },
  safety_inspection: {
    label: 'Safety Inspection',
    color: 'bg-yellow-100 text-yellow-800',
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
          d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
      </svg>
    ),
  },
};

// Mock reports data
const mockReports: Report[] = [
  {
    id: '1',
    title: 'Weekly Maintenance Summary - Week 3',
    description: 'Overview of all maintenance activities completed this week',
    type: 'maintenance_summary',
    status: 'published',
    created_by: 'John Smith',
    created_at: new Date('2024-01-19'),
    updated_at: new Date('2024-01-19'),
  },
  {
    id: '2',
    title: 'Team Performance Review Q1 2024',
    description: 'Quarterly review of maintenance team performance metrics',
    type: 'team_leader_review',
    status: 'draft',
    created_by: 'Sarah Johnson',
    created_at: new Date('2024-01-15'),
    updated_at: new Date('2024-01-18'),
    required_role: ['admin', 'maintenance_team_leader'],
  },
  {
    id: '3',
    title: 'Annual Compliance Audit 2024',
    description: 'Comprehensive audit of regulatory compliance',
    type: 'compliance_audit',
    status: 'published',
    created_by: 'Mike Davis',
    created_at: new Date('2024-01-10'),
    updated_at: new Date('2024-01-17'),
    required_role: ['admin', 'maintenance_team_leader', 'quality_inspector'],
  },
  {
    id: '4',
    title: 'Fleet Status Report - January',
    description: 'Current status of all aircraft in the fleet',
    type: 'fleet_status',
    status: 'published',
    created_by: 'Emily Brown',
    created_at: new Date('2024-01-20'),
    updated_at: new Date('2024-01-20'),
  },
  {
    id: '5',
    title: 'Engine Performance Analysis',
    description: 'Detailed analysis of engine performance across the fleet',
    type: 'performance_analysis',
    status: 'published',
    created_by: 'David Wilson',
    created_at: new Date('2024-01-12'),
    updated_at: new Date('2024-01-16'),
    required_role: ['admin', 'maintenance_team_leader', 'quality_inspector', 'flight_operations'],
  },
  {
    id: '6',
    title: 'Safety Inspection - AC-001',
    description: 'Pre-flight safety inspection report',
    type: 'safety_inspection',
    status: 'published',
    created_by: 'Chris Anderson',
    created_at: new Date('2024-01-18'),
    updated_at: new Date('2024-01-18'),
  },
];

// Report card component
function ReportCard({ report, onView, onEdit, onDelete, onExport }: {
  report: Report;
  onView: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onExport: () => void;
}) {
  const { user, hasAnyRole } = useAuth();
  const config = reportTypeConfig[report.type];
  
  // Check if user can view this report based on required roles
  const canViewReport = !report.required_role || 
    (user && hasAnyRole(report.required_role as any[]));

  // If user doesn't have permission to view, don't render the card
  if (!canViewReport) {
    return null;
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
      <div className="p-5">
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <div className={cn('p-2 rounded-lg', config.color)}>
            {config.icon}
          </div>
          <span
            className={cn(
              'px-2 py-1 text-xs font-medium rounded-full',
              report.status === 'published' && 'bg-green-100 text-green-800',
              report.status === 'draft' && 'bg-yellow-100 text-yellow-800',
              report.status === 'archived' && 'bg-gray-100 text-gray-800'
            )}
          >
            {report.status.charAt(0).toUpperCase() + report.status.slice(1)}
          </span>
        </div>

        {/* Content */}
        <h3 className="text-lg font-semibold text-gray-900 mb-1">
          {report.title}
        </h3>
        <p className="text-sm text-gray-600 mb-3 line-clamp-2">
          {report.description}
        </p>

        {/* Type badge */}
        <div className="mb-3">
          <span className={cn('px-2 py-1 text-xs font-medium rounded', config.color)}>
            {config.label}
          </span>
          {report.required_role && (
            <span className="ml-2 px-2 py-1 text-xs font-medium rounded bg-gray-100 text-gray-600">
              Restricted Access
            </span>
          )}
        </div>

        {/* Meta */}
        <div className="flex items-center text-xs text-gray-500 mb-4">
          <span>By {report.created_by}</span>
          <span className="mx-2">•</span>
          <span>{formatDate(report.created_at)}</span>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 pt-3 border-t border-gray-100">
          <Button variant="primary" size="sm" onClick={onView}>
            View Report
          </Button>

          {/* Edit - only with edit permission */}
          <FeatureGate feature="reports_edit">
            <Button variant="secondary" size="sm" onClick={onEdit}>
              Edit
            </Button>
          </FeatureGate>

          {/* Export - only with export permission */}
          <PermissionGate permission={PERMISSIONS.EXPORT_REPORTS}>
            <Button variant="ghost" size="sm" onClick={onExport}>
              Export
            </Button>
          </PermissionGate>

          {/* Delete - only with delete permission */}
          <FeatureGate feature="reports_delete">
            <Button
              variant="ghost"
              size="sm"
              onClick={onDelete}
              className="text-red-600 hover:text-red-700 hover:bg-red-50 ml-auto"
            >
              Delete
            </Button>
          </FeatureGate>
        </div>
      </div>
    </div>
  );
}

export function ReportsPage() {
  const { user, hasAnyRole } = useAuth();
  const toast = useToast();
  const [activeTab, setActiveTab] = useState<'all' | 'my' | 'team'>('all');

  // Filter reports based on user's role
  const visibleReports = mockReports.filter((report) => {
    if (!report.required_role) return true;
    return user && hasAnyRole(report.required_role as any[]);
  });

  // Handle actions
  const handleViewReport = (report: Report) => {
    toast.info(`Opening report: ${report.title}`);
  };

  const handleEditReport = (report: Report) => {
    toast.info(`Editing report: ${report.title}`);
  };

  const handleDeleteReport = (report: Report) => {
    toast.warning(`Are you sure you want to delete: ${report.title}?`);
  };

  const handleExportReport = (report: Report) => {
    toast.success(`Exporting report: ${report.title}`);
  };

  const handleCreateReport = () => {
    toast.info('Opening create report dialog...');
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Page header */}
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Reports</h1>
            <p className="mt-1 text-sm text-gray-500">
              View and manage maintenance reports
            </p>
          </div>

          {/* Create Report button - only with create permission */}
          <FeatureGate feature="reports_create">
            <Button
              variant="primary"
              onClick={handleCreateReport}
              leftIcon={
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
              }
            >
              Create Report
            </Button>
          </FeatureGate>
        </div>

        {/* Current user info */}
        {user && (
          <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-100">
            <p className="text-sm text-blue-800">
              <span className="font-medium">Logged in as:</span> {user.name} ({ROLE_DISPLAY_NAMES[user.role]})
            </p>
            <p className="text-xs text-blue-600 mt-1">
              Reports are filtered based on your role permissions. You can see {visibleReports.length} of {mockReports.length} total reports.
            </p>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="mb-6 border-b border-gray-200">
        <nav className="-mb-px flex gap-6">
          <button
            onClick={() => setActiveTab('all')}
            className={cn(
              'py-3 text-sm font-medium border-b-2 transition-colors',
              activeTab === 'all'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            )}
          >
            All Reports
          </button>

          {/* My Reports tab - for users who can create reports */}
          <FeatureGate feature="reports_create">
            <button
              onClick={() => setActiveTab('my')}
              className={cn(
                'py-3 text-sm font-medium border-b-2 transition-colors',
                activeTab === 'my'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              )}
            >
              My Reports
            </button>
          </FeatureGate>

          {/* Team Reports tab - only for team leaders */}
          <RoleGate role={['admin', 'maintenance_team_leader']}>
            <button
              onClick={() => setActiveTab('team')}
              className={cn(
                'py-3 text-sm font-medium border-b-2 transition-colors',
                activeTab === 'team'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              )}
            >
              Team Reports
            </button>
          </RoleGate>
        </nav>
      </div>

      {/* Team Leader Reports Section - ONLY visible to team leaders and admins */}
      <RoleGate role={['admin', 'maintenance_team_leader']}>
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            Team Leader Reports
            <span className="ml-2 px-2 py-0.5 bg-purple-100 text-purple-700 text-xs rounded-full">
              Restricted
            </span>
          </h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {visibleReports
              .filter((r) => r.type === 'team_leader_review')
              .map((report) => (
                <ReportCard
                  key={report.id}
                  report={report}
                  onView={() => handleViewReport(report)}
                  onEdit={() => handleEditReport(report)}
                  onDelete={() => handleDeleteReport(report)}
                  onExport={() => handleExportReport(report)}
                />
              ))}
          </div>
          {visibleReports.filter((r) => r.type === 'team_leader_review').length === 0 && (
            <p className="text-sm text-gray-500 italic">No team leader reports available.</p>
          )}
        </div>
      </RoleGate>

      {/* All Reports Grid */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-4">All Available Reports</h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {visibleReports
            .filter((r) => activeTab === 'all' || 
              (activeTab === 'team' && r.type === 'team_leader_review'))
            .map((report) => (
              <ReportCard
                key={report.id}
                report={report}
                onView={() => handleViewReport(report)}
                onEdit={() => handleEditReport(report)}
                onDelete={() => handleDeleteReport(report)}
                onExport={() => handleExportReport(report)}
              />
            ))}
        </div>
      </div>

      {/* Show message about restricted reports for non-team-leaders */}
      <RoleGate role={['maintenance_technician', 'flight_operations', 'viewer']}>
        <div className="mt-8 p-4 bg-amber-50 rounded-lg border border-amber-200">
          <div className="flex items-start gap-3">
            <svg className="w-5 h-5 text-amber-600 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <div>
              <h3 className="text-sm font-medium text-amber-800">Some reports are restricted</h3>
              <p className="text-sm text-amber-700 mt-1">
                Team Leader Reports and some other reports require elevated permissions.
                Contact your supervisor if you need access to these reports.
              </p>
            </div>
          </div>
        </div>
      </RoleGate>
    </div>
  );
}
