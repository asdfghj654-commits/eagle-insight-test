// ============================================================================
// Eagle Insight - Authentication & Authorization Types
// ============================================================================

export type UserRole = 
  | 'admin'
  | 'maintenance_team_leader'
  | 'maintenance_technician'
  | 'quality_inspector'
  | 'flight_operations'
  | 'viewer';

export interface Permission {
  id: string;
  name: string;
  description: string;
}

export interface RolePermissions {
  role: UserRole;
  permissions: string[];
  displayName: string;
  description: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  department?: string;
  isActive: boolean;
  createdAt: Date;
  lastLogin?: Date;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

// Permission constants for role-based UI visibility
export const PERMISSIONS = {
  // Reports
  VIEW_REPORTS: 'view_reports',
  CREATE_REPORTS: 'create_reports',
  EDIT_REPORTS: 'edit_reports',
  DELETE_REPORTS: 'delete_reports',
  EXPORT_REPORTS: 'export_reports',
  
  // Findings
  VIEW_FINDINGS: 'view_findings',
  CREATE_FINDINGS: 'create_findings',
  EDIT_FINDINGS: 'edit_findings',
  DELETE_FINDINGS: 'delete_findings',
  SORT_FINDINGS: 'sort_findings',
  ASSIGN_FINDINGS: 'assign_findings',
  CLOSE_FINDINGS: 'close_findings',
  
  // Maintenance
  VIEW_MAINTENANCE: 'view_maintenance',
  CREATE_MAINTENANCE_TASK: 'create_maintenance_task',
  APPROVE_MAINTENANCE: 'approve_maintenance',
  SCHEDULE_MAINTENANCE: 'schedule_maintenance',
  
  // Insights
  VIEW_INSIGHTS: 'view_insights',
  CONFIGURE_INSIGHTS: 'configure_insights',
  
  // File Management
  UPLOAD_FILES: 'upload_files',
  DELETE_FILES: 'delete_files',
  
  // Administration
  MANAGE_USERS: 'manage_users',
  MANAGE_SETTINGS: 'manage_settings',
  VIEW_AUDIT_LOGS: 'view_audit_logs',
  
  // Data Sources
  MANAGE_DATA_SOURCES: 'manage_data_sources',
  VIEW_DATA_SOURCES: 'view_data_sources',
} as const;

// Role-permission mappings
export const ROLE_PERMISSIONS: Record<UserRole, string[]> = {
  admin: Object.values(PERMISSIONS),
  
  maintenance_team_leader: [
    PERMISSIONS.VIEW_REPORTS,
    PERMISSIONS.CREATE_REPORTS,
    PERMISSIONS.EDIT_REPORTS,
    PERMISSIONS.EXPORT_REPORTS,
    PERMISSIONS.VIEW_FINDINGS,
    PERMISSIONS.CREATE_FINDINGS,
    PERMISSIONS.EDIT_FINDINGS,
    PERMISSIONS.SORT_FINDINGS,
    PERMISSIONS.ASSIGN_FINDINGS,
    PERMISSIONS.CLOSE_FINDINGS,
    PERMISSIONS.VIEW_MAINTENANCE,
    PERMISSIONS.CREATE_MAINTENANCE_TASK,
    PERMISSIONS.APPROVE_MAINTENANCE,
    PERMISSIONS.SCHEDULE_MAINTENANCE,
    PERMISSIONS.VIEW_INSIGHTS,
    PERMISSIONS.UPLOAD_FILES,
    PERMISSIONS.VIEW_DATA_SOURCES,
  ],
  
  maintenance_technician: [
    PERMISSIONS.VIEW_REPORTS,
    PERMISSIONS.VIEW_FINDINGS,
    PERMISSIONS.CREATE_FINDINGS,
    PERMISSIONS.EDIT_FINDINGS,
    PERMISSIONS.VIEW_MAINTENANCE,
    PERMISSIONS.CREATE_MAINTENANCE_TASK,
    PERMISSIONS.VIEW_INSIGHTS,
    PERMISSIONS.UPLOAD_FILES,
  ],
  
  quality_inspector: [
    PERMISSIONS.VIEW_REPORTS,
    PERMISSIONS.CREATE_REPORTS,
    PERMISSIONS.VIEW_FINDINGS,
    PERMISSIONS.CREATE_FINDINGS,
    PERMISSIONS.EDIT_FINDINGS,
    PERMISSIONS.SORT_FINDINGS,
    PERMISSIONS.CLOSE_FINDINGS,
    PERMISSIONS.VIEW_MAINTENANCE,
    PERMISSIONS.VIEW_INSIGHTS,
    PERMISSIONS.UPLOAD_FILES,
    PERMISSIONS.VIEW_DATA_SOURCES,
  ],
  
  flight_operations: [
    PERMISSIONS.VIEW_REPORTS,
    PERMISSIONS.EXPORT_REPORTS,
    PERMISSIONS.VIEW_FINDINGS,
    PERMISSIONS.VIEW_MAINTENANCE,
    PERMISSIONS.VIEW_INSIGHTS,
  ],
  
  viewer: [
    PERMISSIONS.VIEW_REPORTS,
    PERMISSIONS.VIEW_FINDINGS,
    PERMISSIONS.VIEW_MAINTENANCE,
    PERMISSIONS.VIEW_INSIGHTS,
  ],
};

// Display names for roles
export const ROLE_DISPLAY_NAMES: Record<UserRole, string> = {
  admin: 'Administrator',
  maintenance_team_leader: 'Maintenance Team Leader',
  maintenance_technician: 'Maintenance Technician',
  quality_inspector: 'Quality Inspector',
  flight_operations: 'Flight Operations',
  viewer: 'Viewer',
};
