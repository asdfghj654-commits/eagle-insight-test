// ============================================================================
// Eagle Insight - Findings Page
// Demonstrates role-based UI visibility - unauthorized actions are hidden
// ============================================================================

import React, { useState, useMemo } from 'react';
import { Button } from '../ui/Button';
import { useToast } from '../ui/Toast';
import { useAuth } from '../../contexts/AuthContext';
import { 
  PermissionGate, 
  FeatureGate, 
  RoleGate 
} from '../common/RoleBasedAccess';
import { PERMISSIONS, ROLE_DISPLAY_NAMES } from '../../types/auth.types';
import { cn } from '../../lib/utils';

// Types
interface Finding {
  id: string;
  title: string;
  description: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  aircraft_id: string;
  assignee?: string;
  created_at: Date;
  updated_at: Date;
}

type SortField = 'severity' | 'status' | 'created_at' | 'title';
type SortDirection = 'asc' | 'desc';

// Mock data
const mockFindings: Finding[] = [
  {
    id: '1',
    title: 'Engine vibration anomaly detected',
    description: 'Unusual vibration patterns observed during climb phase',
    severity: 'high',
    status: 'open',
    aircraft_id: 'AC-001',
    created_at: new Date('2024-01-15'),
    updated_at: new Date('2024-01-15'),
  },
  {
    id: '2',
    title: 'Landing gear hydraulic leak',
    description: 'Minor hydraulic fluid seepage from left main gear',
    severity: 'medium',
    status: 'in_progress',
    aircraft_id: 'AC-002',
    assignee: 'John Smith',
    created_at: new Date('2024-01-14'),
    updated_at: new Date('2024-01-16'),
  },
  {
    id: '3',
    title: 'Fuel quantity indicator malfunction',
    description: 'Intermittent false readings on center tank gauge',
    severity: 'critical',
    status: 'open',
    aircraft_id: 'AC-001',
    created_at: new Date('2024-01-16'),
    updated_at: new Date('2024-01-16'),
  },
];

// Severity badge component
function SeverityBadge({ severity }: { severity: Finding['severity'] }) {
  const colors = {
    critical: 'bg-red-100 text-red-800 border-red-200',
    high: 'bg-orange-100 text-orange-800 border-orange-200',
    medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    low: 'bg-green-100 text-green-800 border-green-200',
  };

  return (
    <span
      className={cn(
        'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border',
        colors[severity]
      )}
    >
      {severity.charAt(0).toUpperCase() + severity.slice(1)}
    </span>
  );
}

// Status badge component
function StatusBadge({ status }: { status: Finding['status'] }) {
  const colors = {
    open: 'bg-blue-100 text-blue-800',
    in_progress: 'bg-purple-100 text-purple-800',
    resolved: 'bg-green-100 text-green-800',
    closed: 'bg-gray-100 text-gray-800',
  };

  const labels = {
    open: 'Open',
    in_progress: 'In Progress',
    resolved: 'Resolved',
    closed: 'Closed',
  };

  return (
    <span
      className={cn(
        'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium',
        colors[status]
      )}
    >
      {labels[status]}
    </span>
  );
}

export function FindingsPage() {
  const { user, hasPermission } = useAuth();
  const toast = useToast();
  
  const [findings, setFindings] = useState<Finding[]>(mockFindings);
  const [sortField, setSortField] = useState<SortField>('created_at');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [selectedFindings, setSelectedFindings] = useState<Set<string>>(new Set());

  // Sort findings
  const sortedFindings = useMemo(() => {
    return [...findings].sort((a, b) => {
      let comparison = 0;
      
      switch (sortField) {
        case 'severity': {
          const severityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
          comparison = severityOrder[a.severity] - severityOrder[b.severity];
          break;
        }
        case 'status': {
          const statusOrder = { open: 0, in_progress: 1, resolved: 2, closed: 3 };
          comparison = statusOrder[a.status] - statusOrder[b.status];
          break;
        }
        case 'created_at':
          comparison = a.created_at.getTime() - b.created_at.getTime();
          break;
        case 'title':
          comparison = a.title.localeCompare(b.title);
          break;
      }
      
      return sortDirection === 'asc' ? comparison : -comparison;
    });
  }, [findings, sortField, sortDirection]);

  // Handle sort
  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  // Handle finding selection
  const toggleFindingSelection = (id: string) => {
    setSelectedFindings((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  // Handle actions
  const handleCreateFinding = () => {
    toast.info('Opening create finding dialog...');
    // Would open a modal/dialog in real implementation
  };

  const handleEditFinding = (finding: Finding) => {
    toast.info(`Editing finding: ${finding.title}`);
  };

  const handleDeleteFinding = (finding: Finding) => {
    toast.warning(`Are you sure you want to delete: ${finding.title}?`);
  };

  const handleAssignFinding = (finding: Finding) => {
    toast.info(`Opening assign dialog for: ${finding.title}`);
  };

  const handleCloseFinding = (finding: Finding) => {
    setFindings((prev) =>
      prev.map((f) =>
        f.id === finding.id ? { ...f, status: 'closed' as const, updated_at: new Date() } : f
      )
    );
    toast.success(`Finding "${finding.title}" has been closed`);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Page header */}
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Findings</h1>
            <p className="mt-1 text-sm text-gray-500">
              Manage and track maintenance findings across your fleet
            </p>
          </div>

          {/* Create Finding button - only visible with permission */}
          <FeatureGate feature="findings_create">
            <Button
              variant="primary"
              onClick={handleCreateFinding}
              leftIcon={
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
              }
            >
              Create Finding
            </Button>
          </FeatureGate>
        </div>

        {/* Current user info */}
        {user && (
          <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-100">
            <p className="text-sm text-blue-800">
              <span className="font-medium">Logged in as:</span> {user.name} ({ROLE_DISPLAY_NAMES[user.role]})
            </p>
            <p className="text-xs text-blue-600 mt-1">
              Actions are shown/hidden based on your role permissions
            </p>
          </div>
        )}
      </div>

      {/* Toolbar - sorting and bulk actions */}
      <div className="mb-4 flex items-center justify-between gap-4 flex-wrap">
        {/* Sort controls - ONLY visible to users with sort permission */}
        <FeatureGate feature="findings_sort">
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-600">Sort by:</span>
            <div className="flex gap-1">
              {(['severity', 'status', 'created_at', 'title'] as SortField[]).map((field) => (
                <Button
                  key={field}
                  variant={sortField === field ? 'primary' : 'secondary'}
                  size="sm"
                  onClick={() => handleSort(field)}
                  aria-pressed={sortField === field}
                  rightIcon={
                    sortField === field ? (
                      <svg
                        className={cn('w-3 h-3 transition-transform', sortDirection === 'desc' && 'rotate-180')}
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
                      </svg>
                    ) : undefined
                  }
                >
                  {field.replace('_', ' ').replace(/\b\w/g, (l) => l.toUpperCase())}
                </Button>
              ))}
            </div>
          </div>
        </FeatureGate>

        {/* Bulk actions - only for team leaders and admins */}
        <RoleGate role={['admin', 'maintenance_team_leader']}>
          {selectedFindings.size > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">
                {selectedFindings.size} selected
              </span>
              <Button variant="secondary" size="sm">
                Bulk Assign
              </Button>
              <Button variant="secondary" size="sm">
                Bulk Close
              </Button>
            </div>
          )}
        </RoleGate>
      </div>

      {/* Findings table */}
      <div className="bg-white shadow-sm rounded-lg border border-gray-200 overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              {/* Checkbox column - only for users who can assign */}
              <PermissionGate permission={PERMISSIONS.ASSIGN_FINDINGS}>
                <th scope="col" className="w-12 px-4 py-3">
                  <span className="sr-only">Select</span>
                </th>
              </PermissionGate>
              <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Finding
              </th>
              <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Severity
              </th>
              <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Aircraft
              </th>
              <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Assignee
              </th>
              <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {sortedFindings.map((finding) => (
              <tr
                key={finding.id}
                className={cn(
                  'hover:bg-gray-50 transition-colors',
                  selectedFindings.has(finding.id) && 'bg-blue-50'
                )}
              >
                {/* Checkbox - only for users who can assign */}
                <PermissionGate permission={PERMISSIONS.ASSIGN_FINDINGS}>
                  <td className="w-12 px-4 py-4">
                    <input
                      type="checkbox"
                      checked={selectedFindings.has(finding.id)}
                      onChange={() => toggleFindingSelection(finding.id)}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      aria-label={`Select finding: ${finding.title}`}
                    />
                  </td>
                </PermissionGate>

                <td className="px-4 py-4">
                  <div className="text-sm font-medium text-gray-900">{finding.title}</div>
                  <div className="text-sm text-gray-500 truncate max-w-xs">
                    {finding.description}
                  </div>
                </td>

                <td className="px-4 py-4">
                  <SeverityBadge severity={finding.severity} />
                </td>

                <td className="px-4 py-4">
                  <StatusBadge status={finding.status} />
                </td>

                <td className="px-4 py-4 text-sm text-gray-600">
                  {finding.aircraft_id}
                </td>

                <td className="px-4 py-4 text-sm text-gray-600">
                  {finding.assignee || '—'}
                </td>

                <td className="px-4 py-4 text-right">
                  <div className="flex items-center justify-end gap-1">
                    {/* Edit button - only with edit permission */}
                    <PermissionGate permission={PERMISSIONS.EDIT_FINDINGS}>
                      <Button
                        variant="ghost"
                        size="iconSm"
                        onClick={() => handleEditFinding(finding)}
                        aria-label={`Edit ${finding.title}`}
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                            d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                        </svg>
                      </Button>
                    </PermissionGate>

                    {/* Assign button - only with assign permission */}
                    <PermissionGate permission={PERMISSIONS.ASSIGN_FINDINGS}>
                      <Button
                        variant="ghost"
                        size="iconSm"
                        onClick={() => handleAssignFinding(finding)}
                        aria-label={`Assign ${finding.title}`}
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                            d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                      </Button>
                    </PermissionGate>

                    {/* Close button - only with close permission and for open findings */}
                    <PermissionGate permission={PERMISSIONS.CLOSE_FINDINGS}>
                      {finding.status !== 'closed' && (
                        <Button
                          variant="ghost"
                          size="iconSm"
                          onClick={() => handleCloseFinding(finding)}
                          aria-label={`Close ${finding.title}`}
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                              d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </Button>
                      )}
                    </PermissionGate>

                    {/* Delete button - only with delete permission */}
                    <PermissionGate permission={PERMISSIONS.DELETE_FINDINGS}>
                      <Button
                        variant="ghost"
                        size="iconSm"
                        onClick={() => handleDeleteFinding(finding)}
                        aria-label={`Delete ${finding.title}`}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                            d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </Button>
                    </PermissionGate>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Permission info footer */}
      <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
        <h3 className="text-sm font-medium text-gray-700 mb-2">
          Your Permissions
        </h3>
        <div className="flex flex-wrap gap-2">
          {hasPermission(PERMISSIONS.VIEW_FINDINGS) && (
            <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded">View Findings</span>
          )}
          {hasPermission(PERMISSIONS.CREATE_FINDINGS) && (
            <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded">Create Findings</span>
          )}
          {hasPermission(PERMISSIONS.EDIT_FINDINGS) && (
            <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded">Edit Findings</span>
          )}
          {hasPermission(PERMISSIONS.SORT_FINDINGS) && (
            <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded">Sort Findings</span>
          )}
          {hasPermission(PERMISSIONS.ASSIGN_FINDINGS) && (
            <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded">Assign Findings</span>
          )}
          {hasPermission(PERMISSIONS.CLOSE_FINDINGS) && (
            <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded">Close Findings</span>
          )}
          {hasPermission(PERMISSIONS.DELETE_FINDINGS) && (
            <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded">Delete Findings</span>
          )}
        </div>
      </div>
    </div>
  );
}
